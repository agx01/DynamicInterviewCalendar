<?php
/**
 * Plugin Name: Dynamic Interview Calendars
 * Description: Generate the Interview calendars from Google sheets
 * Author: Arijit Ganguly
 * Author URI: arijit.ganguly@jerseystem.org
 * Version: 1.2.0
 * Text Domain: dynamic-interview-calendars
 * Change Log: Updated the script so that the Google sheets is only called when the page is loaded.
 */

 if(!defined('ABSPATH')){
    exit;
 }

 define( 'PLUGIN_WITH_CLASSES__FILE__', __FILE__ );

 class DynamicInterviewCalendar{

    private $wpdb;
    private $db_table_name;

    public function __construct(){
        global $wpdb;
        $this->wpdb = $wpdb;

        $this->db_table_name = $this->wpdb->prefix.'google_appts';

        //Create the required tables in as part of the plugin activation
        register_activation_hook( PLUGIN_WITH_CLASSES__FILE__, array($this, 'plugin_create_db'));

        // //Load the plugin
        // add_action('init', array($this, 'initialize_plugin'));

        //Add assets (js, css, stc)
        add_action('wp_enqueue_scripts', array($this, 'load_assets'));

        //Load javascript
        add_action('wp_footer', array($this, 'load_scripts'));

        //Add shortcode
        add_shortcode( 'dynamic-interview-cals', array($this, 'load_shortcode'));

        //Delete the table on deactivation
        register_uninstall_hook(PLUGIN_WITH_CLASSES__FILE__, array($this, 'plugin_remove_db'));

    }

    public function plugin_create_db(){
        $charset_collate = $this->wpdb->get_charset_collate();

        //Check to see if the table already exists
        if($this->wpdb->get_var("show tables like '$this->db_table_name'") != $this->db_table_name){
            
            $sql = "CREATE TABLE $this->db_table_name(
                department varchar(5),
                firstname varchar(20),
                lastname varchar(20),
                apptlink TEXT,
                PRIMARY KEY (firstname, lastname)
                ) $charset_collate;";

            require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
            dbDelta( $sql);
            // add_option('test_db_version', $test_db_version);
        }
    }

    // public function initialize_plugin(){

    //     $sheetid = "1w7KtDoPt8adBIqRK8g1ua5aOWhV7_zMHJ2hGMvXt8uE";
    //     $sheetname = "interviewsheet";
    //     $header = "true";
    //     $request = "https://script.google.com/macros/s/AKfycbyHY8u3kmsQFc6xgaP7saJsZcQ6VyP4hVyDlmrXFikwsUOr1hJ5FZKTSJp0PGx6ogJ4Mg/exec?".
    //             "spreadsheetid=".$sheetid.
    //             "&sheetname=".$sheetname.
    //             "&header=".$header."";

    //     $response = wp_remote_get($request);
        
    //     echo wp_remote_retrieve_response_code($request);

    //     if (is_array($response) && !is_wp_error( $response )){
    //         $data = json_decode($response['body'], true);
    //         $data = $data['data'];

    //         foreach($data as $item){
                
    //             try {
    //                 $this->wpdb->insert(
    //                     $this->db_table_name,
    //                     array(
    //                         'department' => $item['department'],
    //                         'firstname' => $item['firstname'],
    //                         'lastname' => $item['lastname'],
    //                         'apptlink' => $item['appointmentlink']
    //                     )
    //                 );
    //             } catch (Exception $e) {
    //                 echo 'Caught exception: ',  $e->getMessage(), "\n";
    //             }
                
    //         }
    //     }
    //     else{
    //         echo 'Error fetching data from Google Apps Script web app.';
    //     }

    // }

    public function load_assets(){

        wp_enqueue_style(
            'dynamic-interview-calendar',
            plugin_dir_url(__FILE__). 'css/dynamic-interview-calendars.css',
            array(),
            1,
            'all' 
        );

        // wp_enqueue_scripts(
        //     'dynamic-interview-calendar',
        //     plugin_dir_url(__FILE__).'js/dynamic-interview-calendars.js',
        //     array(),
        //     1,
        //     true
        // );

    }

    public function load_scripts(){
    
    }

    public function get_data_from_sheets(){
        $sheetid = "1w7KtDoPt8adBIqRK8g1ua5aOWhV7_zMHJ2hGMvXt8uE";
        $sheetname = "interviewsheet";
        $header = "true";
        $request = "https://script.google.com/macros/s/AKfycbyHY8u3kmsQFc6xgaP7saJsZcQ6VyP4hVyDlmrXFikwsUOr1hJ5FZKTSJp0PGx6ogJ4Mg/exec?".
                "spreadsheetid=".$sheetid.
                "&sheetname=".$sheetname.
                "&header=".$header."";

        $response = wp_remote_get($request);

        if (is_array($response) && !is_wp_error( $response )){
            $data = json_decode($response['body'], true);
            $data = $data['data'];

            foreach($data as $item){
                
                try {
                    $this->wpdb->insert(
                        $this->db_table_name,
                        array(
                            'department' => $item['department'],
                            'firstname' => $item['firstname'],
                            'lastname' => $item['lastname'],
                            'apptlink' => $item['appointmentlink']
                        )
                    );
                } catch (Exception $e) {
                    echo 'Caught exception: ',  $e->getMessage(), "\n";
                }
                
            }
        }
        else{
            echo 'Error fetching data from Google Apps Script web app.';
        }

    }

    public function load_shortcode(){

        $this->get_data_from_sheets();

        if(isset($_GET['department']) && empty($_GET['department'])){
            $results = $this->wpdb->get_results("SELECT * FROM $this->db_table_name");
        }
        else{
            $results = $this->wpdb->get_results(
                $this->wpdb->prepare(
                    "SELECT * FROM $this->db_table_name WHERE department=%s",
                    $_GET['department']
                )
            );
        }
        $num_cols = 2;

        $col_counter = 0;

        $html_string = "";

        $table_start = "<table class='table' border='1px solid black'>";
        $table_end = "</table>";
        $row_start = "<tr>";
        $row_end = "</tr>";

        
        $num_cells = count($results);

        $html_string = $html_string.$table_start;
        $record_ctr = 0;

        for($i = 0; $i < $num_cells/$num_cols; $i++){
            $html_string = $html_string.$row_start;
            for($col_counter=0; $col_counter < $num_cols; $col_counter++){

                $response = wp_remote_get( $results[$record_ctr]->apptlink );

                // $html_string = $html_string."<td>".wp_remote_retrieve_response_code($response)."</td>";
                // $html_string = $html_string."<td>".gettype(wp_remote_retrieve_response_code($response))."</td>";
                
                
                $html_string = $html_string."<td><iframe src=" . $results[$record_ctr]->apptlink . " style='border-width:0; width:800px; height: 600px;'></iframe></td>";
                $record_ctr ++;
            }
            $html_string = $html_string.$row_end;
        }
        $html_string = $html_string . $table_end;


        return $html_string;
    }

    public function filter_valid_links($results){

        foreach($results as $record){
            $response = wp_remote_get( $record->apptlink );
            if(gettype(wp_remote_retrieve_response_code($response)) === gettype("")){
                echo "Invalid link";
            }
        }

        return $results;
    }


    public function plugin_remove_db(){
        $charset_collate = $this->wpdb->get_charset_collate();

        //Check to see if the table already exists
        if($this->wpdb->get_var("show tables like '$this->db_table_name'") == $this->db_table_name){
            
            $sql = "DROP TABLE $this->db_table_name $charset_collate;";

            require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
            dbDelta( $sql);
            // add_option('test_db_version', $test_db_version);
        }
    }

 }

 new DynamicInterviewCalendar;

?>